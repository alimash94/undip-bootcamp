/*
 * These lines of code is intellectual property of Danomalik Technology
 * No copy part or whole without permission
 * copyright @ Danomalik Technology 2016
 */
package chapter01;

/**
 * Interface for HelloWorldUndip application
 * 
 * @author leevy
 */
public interface IHelloWorld {
    void sayHello(String arg0);
}
