/*
 * These lines of code is intellectual property of Danomalik Technology
 * No copy part or whole without permission
 * copyright @ Danomalik Technology 2016
 */
package chapter01;

/**
 * This is abstract object for HelloWorldUndip Application
 * 
 * @author leevy
 */
public abstract class HelloWorld {
    protected String univName;
    public abstract String info();
}
