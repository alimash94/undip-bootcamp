/*
 * These lines of code is intellectual property of Danomalik Technology
 * No copy part or whole without permission
 * copyright @ Danomalik Technology 2016
 */
package chapter01;

/**
 *
 * @author leevy
 */
public class Constants {
    public static final String UNDIP             = "'UNDIP'";
    public static final String HELLO_WORLD_UNDIP = "'Hello World UNDIP App'";
}
